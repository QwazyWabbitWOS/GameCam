GameCam v1.04 - camera proxy game module for Quake II
Copyright (c) 1998-99, by Avi "Zung!" Rozen
e-mail: zungbang@telefragged.com

**********
This is a special build meant to be installed like
the linux/solaris versions.
**********

Installation
============
Perform the following for each mod you want to add GameCam to:

1. rename the existing gamex86.dll as gamex86.real.dll
2. extract gamex86.dll from this archive to the mod directory

That's it. Have fun.

Usage
=====
Refer to the v1.02 manual, or visit the GameCam site at
http://www.telefragged.com/zungbang/gamecam